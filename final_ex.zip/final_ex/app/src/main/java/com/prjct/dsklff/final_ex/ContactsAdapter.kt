package com.prjct.dsklff.final_ex

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import java.util.ArrayList




class ContactsAdapter(internal var context: Context, internal var contact: ArrayList<Contacts>) : BaseAdapter() {

    override fun getCount(): Int {
        return contact.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val view: View

        if (convertView == null) {
            val layoutInflater = LayoutInflater.from(context)
            view = layoutInflater.inflate(R.layout.lay_conatct, null)
        } else {
            view = convertView
        }

        val imgContact = view.findViewById(R.id.contactImage) as ImageView
        val contactName = view.findViewById(R.id.contactName) as TextView
        val contactGroupName = view.findViewById(R.id.contactGroupName) as TextView




        val contacts = contact[position]
        imgContact.setImageResource(contacts.imageId)
        contactName.setText(contacts.name)
        contactName.setText(contacts.contactGroup)
        System.getProperty("line.separator")
        Log.e("name", contacts.name + " ")

        return view

    }
}
