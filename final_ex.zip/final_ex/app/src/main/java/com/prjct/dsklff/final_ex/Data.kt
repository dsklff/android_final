package com.prjct.dsklff.final_ex

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

class Data : Activity() {

    lateinit var editName: EditText
    lateinit var editEmail: EditText
    lateinit var editNumber: EditText
    lateinit var contactImage: ImageView
    lateinit var save: Button
    private var mGetImage: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.data)

        editName = findViewById(R.id.editName) as EditText
        editEmail = findViewById(R.id.editEmail) as EditText
        editNumber = findViewById(R.id.editNumber) as EditText

        contactImage = findViewById(R.id.ContactImage) as ImageView

        save = findViewById(R.id.save) as Button

        contactImage.setOnClickListener {
            val intent2 = Intent(this@Data, Images::class.java)

            startActivityForResult(intent2, 1)
        }

        save.setOnClickListener {
            val contacts = Contacts(
                editName.text.toString(),
                editEmail.text.toString(), editNumber.text.toString(),
                mGetImage
            )

            val intent5 = Intent(this@Data, MainActivity::class.java)

            intent5.putExtra("data", contacts)
            setResult(2, intent5)

            finish()
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)

        mGetImage = data.extras!!.getInt("img", 1)
        contactImage.setImageResource(mGetImage)

    }
}
