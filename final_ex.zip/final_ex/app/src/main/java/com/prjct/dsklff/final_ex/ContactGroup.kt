package com.prjct.dsklff.final_ex

import android.arch.persistence.room.Entity
import android.arch.persistence.room.ForeignKey
import android.arch.persistence.room.PrimaryKey


@Entity
data class ContactGroup(
    @PrimaryKey(autoGenerate = true)
    var uid: Long,
    var groupName: String?
    var priority: String?
)

@Entity(foreignKeys = arrayOf(ForeignKey(entity = ContactGroup::class,
                                        parentColumns = arrayOf("groupName"),
                                        childColumns = arrayOf("name"),
                                        onDelete = ForeignKey.CASCADE)))