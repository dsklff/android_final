package com.prjct.dsklff.final_ex

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView


class ContactDetails : Activity() {

    lateinit var ContactDetails: Contacts
    private var mContactName: String? = null
    private var mContactNumber: String? = null
    private var mContactEmail: String? = null
    private var mContactImage: Int = 0
    lateinit var details_name: TextView
    lateinit var details_number: TextView
    lateinit var details_email: TextView
    lateinit var details_image: ImageView
    lateinit var backButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.contact_details)

        details_image = findViewById(R.id.details_image) as ImageView

        backButton = findViewById(R.id.backButton) as Button

        details_name = findViewById(R.id.details_name) as TextView
        details_email = findViewById(R.id.details_email) as TextView
        details_number = findViewById(R.id.details_number) as TextView

        var intent9 = Intent()
        intent9 = intent
        ContactDetails = intent9.getSerializableExtra("details") as Contacts

        mContactImage = ContactDetails.imageId;
        mContactNumber = ContactDetails.number;
        mContactName = ContactDetails.name;
        mContactEmail = ContactDetails.email;


        details_name.text = mContactName



        details_number.text = mContactNumber
        details_email.text = mContactEmail
        details_image.setImageResource(mContactImage)

        backButton.setOnClickListener { finish() }
    }
}
