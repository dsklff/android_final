package com.prjct.dsklff.final_ex

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.GridView


class AdapterImages(private val mImageId: IntArray, internal var context: Context) : BaseAdapter() {

    override fun getCount(): Int {
        return mImageId.size
    }

    override fun getItem(position: Int): Any? {
        return null
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val imageView: ImageView

        if (convertView == null) {
            imageView = ImageView(context)
            imageView.layoutParams = GridView.LayoutParams(300, 300)
        } else {
            imageView = convertView as ImageView
        }
        imageView.setImageResource(mImageId[position])
        return imageView
    }
}

