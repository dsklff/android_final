package com.prjct.dsklff.final_ex

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import java.util.ArrayList
import android.arch.persistence.room.RoomDatabase
import android.support.design.widget.FloatingActionButton


class MainActivity : Activity() {

    lateinit var contactAddButton: FloatingActionButton
    lateinit var listContacts: ListView

    lateinit var arrayListContact: ArrayList<Contacts>
    lateinit var contactAdapter: ContactsAdapter
    lateinit var contacts: Contacts

    internal val C_View = 1
    internal val C_Delete = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase::Class, "populus-database").build()

        arrayListContact = ArrayList<Contacts>()

        listContacts = findViewById<ListView> as ListView

        contactAddButton = findViewById<contactAddButton> as FloatingActionButton

        //add button listener
        contactAddButton.setOnClickListener {
            val intent = Intent(this@MainActivity, Data::class.java)
            startActivityForResult(intent, 1)
        }

        contactAdapter = ContactsAdapter(this@MainActivity, arrayListContact)

        listContacts.adapter = contactAdapter

        listContacts.onItemClickListener =
                AdapterView.OnItemClickListener { parent, view, position, id -> registerForContextMenu(listContacts) }

    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo)

        if (v.id == R.id.listView) {
            menu.add(0, C_View, 1, "View")
            menu.add(0, C_Delete, 2, "Delete")

        }

    }

    override fun onContextItemSelected(item: MenuItem): Boolean {


        when (item.itemId) {
            C_View -> {

                val intent6 = Intent(this@MainActivity, ContactDetails::class.java)
                val info1 = item.menuInfo as AdapterView.AdapterContextMenuInfo
                val index1 = info1.position

                intent6.putExtra("details", arrayListContact[index1])

                startActivity(intent6)
            }

            C_Delete -> {
                Toast.makeText(this@MainActivity, "Delete", Toast.LENGTH_SHORT).show()

                val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
                val index = info.position

                Log.e("index", index.toString() + " ")
                arrayListContact.removeAt(index)
                contactAdapter.notifyDataSetChanged()
            }
        }
        return true


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)


        if (resultCode == 2) {

            contacts = data.getSerializableExtra("data") as Contacts

            arrayListContact.add(contacts)
            contactAdapter.notifyDataSetChanged()
        }


    }
}

