package com.prjct.dsklff.final_ex

import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query


interface ContactsDao {
    @Insert
    fun insertAll(contacts: Contacts)

    @Delete
    fun delete(contacts: Contacts)

    @Query("SELECT * FROM contacts")
    fun getAllContacts(): List<Contacts>

    @Query("SELECT * FROM contacts WHERE contactGroup LIKE :group")
    fun getAllPeopleWithThisContactGroup(group: String): List<Contacts>
}

