package com.prjct.dsklff.final_ex

import android.arch.persistence.room.Entity
import android.arch.persistence.room.ForeignKey
import android.arch.persistence.room.PrimaryKey
import java.io.Serializable

@Entity
data class Contacts(@PrimaryKey(autoGenerate = true)
                    var name: String?,
                    var email: String?,
                    var number: String?,
                    var homeNumber: String?,
                    var workNumber: String?,
                    var imageId: Int,
                    var contactGroup: ContactGroup ) : Serializable


