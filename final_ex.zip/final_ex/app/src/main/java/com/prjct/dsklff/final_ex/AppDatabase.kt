package com.prjct.dsklff.final_ex

import android.arch.persistence.room.RoomDatabase
import android.arch.persistence.room.Database


@Database(entities = arrayOf(Contacts::class, ContactGroup::class), version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract val contactsDao: ContactsDao


}

